#!/usr/bin/env sh
../../../src/LeagueAPICLI/leagueapicli help summoner:get-by-name
echo
echo Press any key to continue . . .
read