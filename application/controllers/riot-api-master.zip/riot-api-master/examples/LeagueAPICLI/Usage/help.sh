#!/usr/bin/env sh
../../../src/LeagueAPICLI/leagueapicli help
echo
echo Press any key to continue . . .
read