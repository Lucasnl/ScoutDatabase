#!/usr/bin/env sh
../../../src/LeagueAPICLI/leagueapicli list summoner
echo
echo Press any key to continue . . .
read