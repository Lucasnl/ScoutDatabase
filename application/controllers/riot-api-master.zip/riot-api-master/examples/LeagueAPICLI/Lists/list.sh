#!/usr/bin/env sh
../../../src/LeagueAPICLI/leagueapicli list
echo
echo Press any key to continue . . .
read